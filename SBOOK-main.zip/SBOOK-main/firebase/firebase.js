// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore,collection, addDoc, getDocs, doc, updateDoc, deleteDoc,  query, where, getDoc } from "firebase/firestore";
import ReactNativeAsyncStorage from '@react-native-async-storage/async-storage';
import {getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword,  initializeAuth, getReactNativePersistence} from "firebase/auth"
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBHswWaplnWKRe_J5sZ9bUu3yy8nOS2RgM",
  authDomain: "sbook-32ec1.firebaseapp.com",
  projectId: "sbook-32ec1",
  storageBucket: "sbook-32ec1.firebasestorage.app",
  messagingSenderId: "628762673439",
  appId: "1:628762673439:web:a6d83d554ae8f98141b02a"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(ReactNativeAsyncStorage)
});
const db = getFirestore(app);
export{app, db, getFirestore,collection, addDoc,  getDocs, doc, updateDoc, deleteDoc,auth, getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword , query, where, getDoc};