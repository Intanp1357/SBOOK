import { StyleSheet, Text,  TouchableOpacity, View } from 'react-native'
import React from 'react'
import Ionicons from '@expo/vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';

export default function pilihrole() {
    const navigation = useNavigation()
  return (
    <>
    <TouchableOpacity style={{marginTop:30, marginLeft:10}} onPress={()=>navigation.navigate('Awal')}>
        <Ionicons name="arrow-back" size={24} color="black" />
    </TouchableOpacity> 
    <Text style={{
        fontWeight:'bold',
        fontSize:30,
        marginTop:60,
        marginLeft:20
    }}>Masuk Sebagai</Text>
    <View style={{
        flex:0.5,
        alignItems:"center",
        justifyContent:'center',
    }}>

        <TouchableOpacity style={{
            alignItems:'center',
            justifyContent:'center',
            width:'70%',
            borderWidth:5,
            borderRadius:10,
            height:50
        }} onPress={()=>navigation.navigate("Halaman Awal Admin")}><Text> Admin</Text></TouchableOpacity>
        <TouchableOpacity style={{
            alignItems:'center',
            justifyContent:'center',
            width:'70%',
            borderWidth:5,
            marginTop:10,
            borderRadius:10,
            height:50
        }} onPress={()=>navigation.navigate('Halaman Awal Customer')} ><Text>Customer</Text></TouchableOpacity>
    </View>
    </>
  )
}

