import { View, Text,StyleSheet, TouchableOpacity } from 'react-native'
import { useNavigation } from '@react-navigation/native'
import React from 'react'


export default function HalamanAwalCustomer(){
    const navigation=useNavigation()
    return (
        <View style={styles.container}>
          <Text style={styles.teks}>SBook</Text>
          <Text style={styles.teks2}>Menyewa lapangan menjadi mudah</Text>
          <Text style={styles.teks2}>menggunakan Sbook</Text>
          <TouchableOpacity style={styles.tombol} onPress={()=>navigation.navigate('RegisterCustomer')}> 
            <Text style={{color:'white'}}>Register</Text>
          </TouchableOpacity>
        </View>
      )
}
const styles= StyleSheet.create({
    container:{
      backgroundColor:'white',
      flex : 1,
      alignItems: 'center',
      justifyContent:'center'
    },
    teks:{
        fontWeight:'bold',
        fontSize:20
    },
    teks2:{
        color:'grey',
        fontSize:15
    },
    tombol:{
        backgroundColor:'black',
        borderWidth:2,
        justifyContent:'center',
        alignItems:'center',
        width:'50%',
        height:30,
        marginTop:20,
        marginBottom:10,
        borderRadius:5
    }
    

})
