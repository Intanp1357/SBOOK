import { View, Text, TextInput, StyleSheet, TouchableOpacity, Alert } from 'react-native'
import React,{useState} from 'react'
import { useNavigation } from '@react-navigation/native'
import { db,collection, addDoc,getAuth,signInWithEmailAndPassword,getDocs,query,where} from '../../../firebase/firebase';

export default function Login() {
  const Navigation = useNavigation();
  const auth = getAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    if (!username || !password) {
      Alert.alert('Error', 'Semua kolom harus terisi');
      return;
    }
  
    try {
      const userCredential = await signInWithEmailAndPassword(auth, username, password);
      const user = userCredential.user;
      const usersCollection = collection(db, 'Profile Customer');
      console.log(user.email);
  
      // Log seluruh data di koleksi
      const allDocsSnapshot = await getDocs(usersCollection);
      console.log('Log seluruh data di koleksi Profile Customer:');
      allDocsSnapshot.forEach(doc => {
        console.log(`ID Dokumen: ${doc.id}, Data:`, doc.data());
      });
  
      // Query data berdasarkan Username
      const q = query(usersCollection, where('Username', '==', user.email));
      const querySnapshot = await getDocs(q);
  
      if (querySnapshot.empty) {
        console.log('Data tidak ditemukan untuk email:', user.email);
        Alert.alert('Error', 'Data pengguna tidak ditemukan di database');
        return;
      }
  
      querySnapshot.forEach((doc) => {
        console.log("Data ditemukan untuk email:", user.email);
        const DataProfileCustomer = doc.data();
        const IdProfileCustomer = doc.id;
        console.log('Data pengguna:', DataProfileCustomer);
        console.log('ID dokumen:', IdProfileCustomer);
        Alert.alert('Sukses', 'Login berhasil');
        Navigation.navigate('BerandaCustomer', { IdProfileCustomer: doc.id });
      });
    } catch (error) {
      console.log('Login gagal:', error.message);
      Alert.alert('Gagal', 'Login gagal. Silakan periksa email dan password Anda.');
    }
  };
  

  return (
    <View style={styles.container}>
      <Text style={styles.Teks}>LOGIN</Text>
      <TextInput
        placeholder="Masukkan Username"
        style={styles.input}
        value={username}
        onChangeText={setUsername}
        keyboardType="email-address"
      />
      <TextInput
        placeholder="Masukkan Password"
        style={styles.input}
        value={password}
        onChangeText={setPassword}
        secureTextEntry={false}
      />
      <TouchableOpacity style={styles.tombol} onPress={handleLogin}>
        <Text style={styles.textmasuk}> Masuk</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  Teks: {
    fontSize: 20,
    color: 'black',
    paddingBottom: 40,
    fontWeight: 'bold',
  },
  input: {
    borderColor: '#211A2C',
    borderWidth: 3,
    borderRadius: 10,
    width: '80%',
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  tombol: {
    backgroundColor: 'black',
    width: '15%',
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  textmasuk: {
    fontSize: 16,
    color: 'white',
  },
});
