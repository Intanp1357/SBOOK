import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert} from 'react-native'
import React,{useState} from 'react'
import { useNavigation } from '@react-navigation/native'
import { db,collection, addDoc,getAuth, createUserWithEmailAndPassword } from '../../firebase/firebase';

export default function RegisterCustomer() {
  const Navigation = useNavigation()
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const auth = getAuth()
  const handleRegister = async() => {
    if (!name || !address || !phoneNumber || !username || !password) {
      Alert.alert('Peringatan', 'Semua kolom harus diisi!');
      return;
    }
    if (name.length > 50) {
      Alert.alert('Peringatan', 'Nama Lapangan maksimal 50 karakter!');
      return;
    }
    if (address.length < 20) {
      Alert.alert('Peringatan', 'Alamat minimal 20 karakter!');
      return;
    }
    if (!/^\d{10,12}$/.test(phoneNumber)) {
      Alert.alert('Peringatan', 'Nomor handphone harus terdiri dari 10-12 angka!');
      return;
    }
    if (username.length <= 10) {
      Alert.alert('Peringatan', 'Username terlalu pendek');
      return;
    }
    if (!username.includes('@')) {
      Alert.alert('Peringatan', 'Username harus mengandung karakter "@"!');
      return;
    }
    if (password.length > 8) {
      Alert.alert('Peringatan', 'Password maksimal 8 karakter!');
      return;
    }
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, username, password);
      const user = userCredential.user;
      await addProfileAdmin();

      Navigation.navigate('BerandaCustomer');
    } catch (error) {
      console.error("Error saat registrasi:", error.message);
      Alert.alert('Error', error.message);
    }
  };
  const addProfileAdmin = async()=>{
    try {
      const docRef = await addDoc(collection(db, "Profile Customer"), {
        Nama : name,
        Alamat : address,
        NoHP : phoneNumber,
        Username : username,
        Password : password
      });
      console.log("Document written with ID: ", docRef.id);
      setName('');
      setAddress('');
      setPhoneNumber('');
      setUsername('');
      setPassword('');
    } catch (e) {
      console.error("Error adding document: ", e);
    }
  }
  return (
    <>
      <Text style={styles.Teks}>REGISTER</Text>
      <View style={styles.container}>
      <Text style={{fontWeight:'bold'}}>Nama</Text>
      <TextInput placeholder='Masukkan Nama' style={styles.tombol} value={name} onChangeText={setName}></TextInput>
      <Text style={{fontWeight:'bold'}}>Alamat</Text>
      <TextInput placeholder='Masukkan Alamat' style={styles.tombol} value={address} onChangeText={setAddress}></TextInput>
      <Text style={{fontWeight:'bold'}}>No HP</Text>
      <TextInput placeholder='Masukkan Nomor Handphone' style={styles.tombol} value={phoneNumber} onChangeText={setPhoneNumber}></TextInput>
      <Text style={{fontWeight:'bold'}}>Username</Text>
      <TextInput placeholder='Masukkan Username' style={styles.tombol} value={username} onChangeText={setUsername}></TextInput>
      <Text style={{fontWeight:'bold'}}>Password</Text>
      <TextInput placeholder='Masukkan Password' style={styles.tombol} value ={password} onChangeText={setPassword}></TextInput>
      <TouchableOpacity style={{justifyContent:'center', alignItems:'center',backgroundColor:'black', width:'90%', height:50, borderRadius: 20}} onPress={handleRegister}  >
        <Text style={styles.textmasuk}>   Masuk</Text>
      </TouchableOpacity>
      <Text style={{alignSelf:'center'}}>Sudah Punya Akun?</Text>
      <TouchableOpacity onPress={()=>Navigation.navigate('Login')}>
      <Text style={{textDecorationLine:'underline',color:'blue', marginLeft:150}}>Login</Text>
      </TouchableOpacity>
      </View>
    </>
  )
}
const styles= StyleSheet.create({
    container:{
      flex : 1,
      marginLeft:20,
      marginTop:40

    },
    Teks:{
      fontSize:20,
      color:'black',
      fontWeight:'bold',
      alignSelf:'center',
      marginTop:70
    },
    input:{
      borderColor:'#211A2C',
      borderWidth:3,
      borderRadius:10,
      width: '80%',
      marginBottom:20
    },
    tombol:{
      borderColor:'grey',
      borderWidth:3, 
      width:'90%', 
      borderRadius: 20, 
      marginBottom: 15
    },
    textmasuk:{
      fontSize:16,
      color:'white',
    }
  })
