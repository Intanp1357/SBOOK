import { StyleSheet, Text, View, TouchableOpacity, Alert, TextInput } from 'react-native';
import React, { useState, useEffect } from 'react';
import { useRoute } from '@react-navigation/native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { db, doc, getDoc } from '../../../firebase/firebase';

export default function Penyewaan() {
  const route = useRoute();
  const { lapanganId, IdProfileCustomer, JenisLapangan} = route.params;
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [lapanganDetail, setLapanganDetail] = useState(null);

  const getLapanganDetail = async () => {
    try {
        if (!lapanganId || !JenisLapangan) {
            throw new Error('Parameter lapanganId atau JenisLapangan kosong');
          }
      
        const collectionMap = {
            Basket: 'Data Lapangan Basket',
            Badminton: 'Data Lapangan Badminton',
            Futsal: 'Data Lapangan Futsal',
          };
      
        const collectionName = collectionMap[JenisLapangan];
          if (!collectionName) {
            throw new Error('Jenis lapangan tidak valid');
          }
      
        const docRef = doc(db, collectionName, lapanganId);
        const docSnap = await getDoc(docRef);
      
          if (docSnap.exists()) {
            setLapanganDetail(docSnap.data());
            console.log('Detail Lapangan:', docSnap.data());
          } else {
            Alert.alert('Peringatan', 'Data lapangan tidak ditemukan.');
          }
        } catch (error) {
          console.error('Gagal memuat detail lapangan:', error.message);
          Alert.alert('Error', error.message);
        }
      };

  useEffect(() => {
    getLapanganDetail();
  }, [lapanganId, JenisLapangan]);

  if (!lapanganDetail) {
    return <Text>Loading...</Text>;
  }

  // Fungsi untuk menangani perubahan tanggal dan waktu
  const handleDateChange = (event, date) => {
    setShowDatePicker(false);
    if (event.type === 'set' && date) {
      setSelectedDate(date);
      setShowDatePicker(false);
    } else if (event.type === 'dismissed') {
      setShowDatePicker(false); 
    }
  };

    const prosesPenyewaan = () => {
    const now = new Date();
  
    // Ensure that `JamMulai` and `JamSelesai` are valid strings in the format 'HH:MM'
    if (!lapanganDetail.JamMulai || !lapanganDetail.JamSelesai) {
      Alert.alert('Error', 'Jam mulai atau jam selesai lapangan tidak ditemukan.');
      return;
    }
  
    // Extract hours and minutes from 'HH:MM' format
    const jamMulaiParts = lapanganDetail.JamMulai.split(':');
    const jamSelesaiParts = lapanganDetail.JamSelesai.split(':');
    console.log(jamMulaiParts)
  
    
    const startHour = parseInt(jamMulaiParts[0], 10);
    const startMinute = parseInt(jamMulaiParts[1], 10);
    const endHour = parseInt(jamSelesaiParts[1], 10);
    const endMinute = parseInt(jamSelesaiParts[1], 10);
    console.log(startHour)
    console.log(startMinute)
  
    // If any of the extracted parts are invalid
    if (isNaN(startHour) || isNaN(startMinute) || isNaN(endHour) || isNaN(endMinute)) {
      Alert.alert('Error', 'Format jam mulai atau jam selesai tidak valid.');
      return;
    }
  
    // Set the start and end times using the selected date
    const lapanganStartTime = new Date(selectedDate);
    lapanganStartTime.setHours(startHour, startMinute);
    console.log(lapanganStartTime)
  
    const lapanganEndTime = new Date(selectedDate);
    lapanganEndTime.setHours(endHour, endMinute);
  
    console.log(lapanganStartTime, lapanganEndTime);
    console.log(selectedDate)
  
    // Validate the selected date and time
    if (selectedDate.toDateString() === now.toDateString()) {
      if (selectedDate < lapanganStartTime) {
        Alert.alert('Error', `Tanggal dan waktu tidak valid. Maksimal Penyewaan dapat dilakukan 5 jam sebelum pukul ${lapanganDetail.JamMulai}.`);
        return;
      } else if (selectedDate >= lapanganStartTime) {
        Alert.alert('Error', `Penyewaan sudah melebihi jam selesai (${lapanganDetail.JamSelesai}).`);
        return;
      }
    } else if (selectedDate >= lapanganStartTime || lapanganStartTime >= selectedDate) {
      Alert.alert('Sukses', 'Penyewaan lapangan berhasil dilakukan!');
    } else {
      Alert.alert('Error', 'Tanggal dan waktu penyewaan tidak valid.');
    }
  };
  
  
  
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Anda sedang menyewa lapangan:</Text>
      <Text style={styles.text}>ID: {lapanganId}</Text>
      <Text style={styles.text}>Nama Lapangan: {lapanganDetail.namaLapangan}</Text>
      <Text style={styles.text}>Harga: {lapanganDetail.Harga}</Text>
      <Text style={styles.text}>Fasilitas: {lapanganDetail.fasilitas}</Text>
      <Text style={styles.text}>Jam mulai: {lapanganDetail.JamMulai}</Text>
      <Text style={styles.text}>Jam selesai: {lapanganDetail.JamSelesai}</Text>

      <TouchableOpacity style={styles.dateButton} onPress={() => setShowDatePicker(true)}>
        <Text style={styles.buttonText}>Pilih Tanggal Penyewaan</Text>
      </TouchableOpacity>

      {showDatePicker && (
        <DateTimePicker
          value={selectedDate}
          mode="date"
          display="default"
          onChange={handleDateChange} // Menggunakan fungsi terpisah untuk menangani perubahan
          minimumDate={new Date()} // Menyaring tanggal yang bisa dipilih (tidak sebelum sekarang)
        />
      )}

      <Text style={styles.text}>
        Tanggal Terpilih: {selectedDate.toLocaleDateString()} 
      </Text>

      <TouchableOpacity style={styles.button} onPress={prosesPenyewaan}>
        <Text style={styles.buttonText}>Konfirmasi Penyewaan</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    
  },
  text: {
    fontSize: 18,
    marginBottom: 10,
  },
  dateButton: {
    padding: 10,
    backgroundColor: 'gray',
    borderRadius: 5,
    marginBottom: 20,
    alignItems: 'center',
  },
  button: {
    padding: 10,
    backgroundColor: 'black',
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
});
