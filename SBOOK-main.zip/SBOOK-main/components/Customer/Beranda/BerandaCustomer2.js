import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function BerandaCustomer2() {
  return (
    <View style={styles.container}>
      <Text style={{marginTop:50, marginLeft:10, fontSize:43}}>SBOOK !</Text>
      <Text style={{marginLeft:10, fontSize:15, color:'gray'}}>Selamat Datang, Lapangan
      mana nih yang ingin kamu sewa?</Text>
      <View style={{
        flex:1,
        flexDirection:'column',
        marginTop:20,

      }}>
    
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        
    }
})