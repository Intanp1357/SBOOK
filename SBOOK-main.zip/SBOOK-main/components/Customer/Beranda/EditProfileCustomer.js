import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import React, { useState, useEffect } from 'react';
import { useNavigation, useRoute, useFocusEffect } from '@react-navigation/native';
import { db, doc, getDoc } from '../../../firebase/firebase';
import FontAwesome from '@expo/vector-icons/FontAwesome';


export default function EditProfileCustomer() {
  const route = useRoute();
  const navigation = useNavigation()
  const { IdProfileCustomer } = route.params;
  const [Nama, setNama] = useState('');
  const [Alamat, setAlamat] = useState('');
  const [NoHp, setNoHP] = useState('');
  const [Username, setUsername] = useState('');
  const [Password, setPassword] = useState('');

  const getProfileCustomer = async () => {
    if (!IdProfileCustomer) {
      console.log('IdProfileCustomer tidak diteruskan!');
      return;
    }
    console.log(IdProfileCustomer); // Untuk log debugging
    try {
      const docRef = doc(db, 'Profile Customer', IdProfileCustomer);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const userData = docSnap.data();
        console.log('Data Profil Customer:', userData);
        setNama(userData.Nama);
        setAlamat(userData.Alamat);
        setNoHP(userData.NoHP);
        setUsername(userData.Username);
        setPassword(userData.Password)
      } else {
        console.log('Dokumen tidak ditemukan!');
      }
    } catch (error) {
      console.error('Gagal mengambil data:', error.message);
    }
  };

  useFocusEffect(
    React.useCallback(() => {
      getProfileCustomer();
    }, [IdProfileCustomer])
  );

  return (
    <View style={styles.container}>
        <Text style={styles.label}>Nama</Text>
      <TouchableOpacity style={styles.item} onPress={()=>navigation.navigate('EditNamaCustomer',{IdProfileCustomer})}>
        <Text>{Nama}</Text>
        <FontAwesome name="pencil-square-o" size={24} color="black" />
      </TouchableOpacity>
      <Text style={styles.label}>Alamat</Text>
      <TouchableOpacity style={styles.item} onPress={()=>navigation.navigate('EditAlamatCustomer',{IdProfileCustomer})}>
        <Text>{Alamat}</Text>
        <FontAwesome name="pencil-square-o" size={24} color="black" />
      </TouchableOpacity>
      <Text style={styles.label}>No HP</Text>
      <TouchableOpacity style={styles.item} onPress={()=>navigation.navigate('EditNoHpCustomer',{IdProfileCustomer})}>
        <Text>{NoHp}</Text>
        <FontAwesome name="pencil-square-o" size={24} color="black" />
      </TouchableOpacity>
      <Text style={styles.label}>Username & Password</Text>
      <TouchableOpacity style={styles.item} onPress={()=>navigation.navigate('EditUsernameCustomer',{IdProfileCustomer})}>
        <Text >{Username}</Text>
        <FontAwesome name="pencil-square-o" size={24} color="black" />
      </TouchableOpacity>
      <TouchableOpacity style={styles.item} onPress={()=>navigation.navigate('EditUsernameCustomer',{IdProfileCustomer})}>
        <Text >{Password}</Text>
        <FontAwesome name="pencil-square-o" size={24} color="black" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 100,
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center', // Ikon dan teks sejajar
    justifyContent: 'space-between', // Pisahkan teks dan ikon
    paddingHorizontal: 15, // Tambahkan ruang horizontal
    borderWidth: 2,
    borderRadius: 5,
    marginHorizontal: 10,
    marginBottom: 15,
    borderColor: 'gray',
    height: 50,
  },
  label:{
    marginBottom:5,
    marginLeft:10,
    fontWeight:'bold'
  }
});
