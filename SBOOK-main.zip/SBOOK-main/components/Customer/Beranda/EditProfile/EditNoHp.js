import React, { useState, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from "react-native";
import { useRoute } from "@react-navigation/native";
import { db, doc, getDoc, updateDoc, collection, getDocs } from "../../../../firebase/firebase";

export default function EditNoHpCustomer() {
  const route = useRoute();
  const { IdProfileCustomer } = route.params;
  const [NoHP, setNoHP] = useState("");
  const [newNoHP, setNewNoHP] = useState("");


  const getProfileCustomer= async () => {
    if (!IdProfileCustomer) {
      console.log("IdProfileCustomer tidak diteruskan!");
      return;
    }
    try {
      const docRef = doc(db, "Profile Customer", IdProfileCustomer);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const userData = docSnap.data();
        setNoHP(userData.NoHP);
      } else {
        console.log("Dokumen tidak ditemukan!");
      }
    } catch (error) {
      console.error("Gagal mengambil data:", error.message);
    }
  };

  const updateNoHP = async () => {
    if (!newNoHP.trim()) {
      Alert.alert("Peringatan", "NoHP tidak boleh kosong!");
      return;
    }
    try {
      const docRefProfileCustomer= doc(db, "Profile Customer", IdProfileCustomer);
      await updateDoc(docRefProfileCustomer, { NoHP: newNoHP});
      Alert.alert("Sukses", "NoHP berhasil diperbarui!");
      setNewNoHP(""); // Reset input field
    } catch (error) {
      console.error("Gagal memperbarui data:", error.message);
      Alert.alert("Error", "Gagal memperbarui NoHP!");
    }
  };

  useEffect(() => {
    getProfileCustomer();
  }, [IdProfileCustomer]);

  return (
    <View style={styles.container}>
      <Text style={{ fontWeight: "bold", marginBottom: 10 }}>NoHP Saat Ini</Text>
      <Text style={{ alignItems: "center", borderWidth: 1, marginBottom: 10, height: 25 }}> {NoHP}</Text>
      <TextInput
        placeholder="Masukkan NoHP Baru"
        value={newNoHP}
        onChangeText={setNewNoHP}
        style={styles.textBox}
      />
      <TouchableOpacity style={styles.button} onPress={updateNoHP}>
        <Text style={styles.buttonText}>Update NoHP</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 175,
    padding: 20,
  },
  textBox: {
    borderWidth: 1,
    borderColor: "black",
    padding: 10,
    marginBottom: 20,
  },
  button: {
    backgroundColor: "#4CAF50",
    padding: 10,
    alignItems: "center",
    borderRadius: 5,
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
  },
});
