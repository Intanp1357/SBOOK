import React, { useState, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from "react-native";
import { useRoute } from "@react-navigation/native";
import { db, doc, getDoc, updateDoc, collection, getDocs } from "../../../../firebase/firebase";

export default function EditNamaCustomer() {
  const route = useRoute();
  const { IdProfileCustomer } = route.params;
  const [Nama, setNama] = useState("");
  const [newNama, setNewNama] = useState("");


  const getProfileCustomer= async () => {
    if (!IdProfileCustomer) {
      console.log("IdProfileCustomer tidak diteruskan!");
      return;
    }
    try {
      const docRef = doc(db, "Profile Customer", IdProfileCustomer);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const userData = docSnap.data();
        setNama(userData.Nama);
      } else {
        console.log("Dokumen tidak ditemukan!");
      }
    } catch (error) {
      console.error("Gagal mengambil data:", error.message);
    }
  };

  const updateNama = async () => {
    if (!newNama.trim()) {
      Alert.alert("Peringatan", "Nama tidak boleh kosong!");
      return;
    }
    try {
      const docRefProfileCustomer= doc(db, "Profile Customer", IdProfileCustomer);
      await updateDoc(docRefProfileCustomer, { Nama: newNama});
      Alert.alert("Sukses", "Nama berhasil diperbarui!");
      setNewNama(""); // Reset input field
    } catch (error) {
      console.error("Gagal memperbarui data:", error.message);
      Alert.alert("Error", "Gagal memperbarui nama!");
    }
  };

  useEffect(() => {
    getProfileCustomer();
  }, [IdProfileCustomer]);

  return (
    <View style={styles.container}>
      <Text style={{ fontWeight: "bold", marginBottom: 10 }}>Nama Saat Ini</Text>
      <Text style={{ alignItems: "center", borderWidth: 1, marginBottom: 10, height: 25 }}> {Nama}</Text>
      <TextInput
        placeholder="Masukkan Nama Baru"
        value={newNama}
        onChangeText={setNewNama}
        style={styles.textBox}
      />
      <TouchableOpacity style={styles.button} onPress={updateNama}>
        <Text style={styles.buttonText}>Update Nama</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 175,
    padding: 20,
  },
  textBox: {
    borderWidth: 1,
    borderColor: "black",
    padding: 10,
    marginBottom: 20,
  },
  button: {
    backgroundColor: "#4CAF50",
    padding: 10,
    alignItems: "center",
    borderRadius: 5,
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
  },
});
