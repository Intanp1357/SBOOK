import React from "react";
import { Button, TouchableOpacity, View, StyleSheet, Text, Alert} from "react-native";
import { useState, useEffect } from "react";
import { TextInput } from "react-native-gesture-handler";
import { useNavigation, useRoute } from "@react-navigation/native";
import { db, doc,getDoc, getDocs, updateDoc, collection, getAuth, createUserWithEmailAndPassword, auth} from '../../../../firebase/firebase';

export default function EditUsernameCustomer(){
  const route = useRoute();
  const { IdProfileCustomer} = route.params;
  const [Username, setUsername] = useState("");
  const [newUsername, setNewUsername] = useState("");
  const [Password, setPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");

  const getProfileCustomer = async () => {
    if (!IdProfileCustomer) {
      console.log("IdProfileCustomer tidak diteruskan!");
      return;
    }
    try {
      const docRef = doc(db, "Profile Customer", IdProfileCustomer);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const userData = docSnap.data();
        setUsername(userData.Username);
        setPassword(userData.Password); 
      } else {
        console.log("Dokumen tidak ditemukan!");
      }
    } catch (error) {
      console.error("Gagal mengambil data:", error.message);
    }
  };

  const updateUsn = async () => {
    if (!newUsername.trim()&&!newPassword.trim()) {
      Alert.alert("Peringatan", "Username dan Password tidak boleh kosong!");
      return;
    }
    try {
      const docRefProfileCustomer = doc(db, "Profile Customer", IdProfileCustomer);
      await updateDoc(docRefProfileCustomer, { Username: newUsername });
      await updateDoc(docRefProfileCustomer, { Password: newPassword });
      const userCredential = await createUserWithEmailAndPassword(auth, newUsername, newPassword);
      const user = userCredential.user;
      Alert.alert("Sukses", "Username dan Password Berhasil Diperbarui");
      setNewUsername("");
      setNewPassword("")
    } catch (error) {
      console.error("Gagal memperbarui data:", error.message);
      Alert.alert("Error", "Gagal memperbarui Username dan Password!");
    }
  };

  useEffect(() => {
    getProfileCustomer();
  }, [IdProfileCustomer]);

  return (
    <View style={styles.container}>
      <Text style={{ fontWeight: "bold", marginBottom: 10 }}>Username & Password Saat Ini</Text>
      <Text style={{ alignItems: "center", borderWidth: 1, marginBottom: 10, height: 25 }}> {Username}</Text>
      <Text style={{ alignItems: "center", borderWidth: 1, marginBottom: 10, height: 25 }}> {Password}</Text>
      <TextInput
        placeholder="Masukkan Username Baru"
        value={newUsername}
        onChangeText={(text) => setNewUsername(text.toLowerCase())}
        style={styles.textBox}
      />
      <TextInput
        placeholder="Masukkan Password Baru"
        value={newPassword}
        onChangeText={setNewPassword}
        style={styles.textBox}
      />
      <TouchableOpacity style={styles.button} onPress={updateUsn}>
        <Text style={styles.buttonText}>Update Username & Password</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 175,
    padding: 20,
  },
  textBox: {
    borderWidth: 1,
    borderColor: "black",
    padding: 10,
    marginBottom: 20,
  },
  button: {
    backgroundColor: "#4CAF50",
    padding: 10,
    alignItems: "center",
    borderRadius: 5,
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
  },
});
