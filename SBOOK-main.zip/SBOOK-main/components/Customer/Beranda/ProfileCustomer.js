import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import React, { useEffect, useState } from 'react';
import { useNavigation, useRoute, useFocusEffect } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { db, doc, getDoc } from '../../../firebase/firebase';

export default function ProfileCustomer() {
  const Navigation = useNavigation();
  const Route = useRoute();
  const [nama, setNama] = useState('');
  const [NoHP, setNoHP] = useState('')
  const { IdProfileCustomer } = Route.params;
  console.log(Route.params)
  const getProfileData = async () => {
    if (!IdProfileCustomer) {
      console.log('IdProfileAdmin tidak diteruskan!');
      return;
    }
    console.log(IdProfileCustomer);  
    try {
      const docRef = doc(db, 'Profile Customer', IdProfileCustomer); 
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const userData = docSnap.data(); 
        console.log('Data Profil Customer:', userData);
        if (userData.Nama) {
          setNama(userData.Nama); 
        }
        if (userData.NoHP){
            setNoHP(userData.NoHP)
        }
      } else {
        console.log('Data tidak ditemukan untuk ID ini!');
      }
    } catch (error) {
      console.error('Gagal mengambil data:', error.message);
    }
  };
  useFocusEffect(
    React.useCallback(() => {
      getProfileData();
    }, [IdProfileCustomer])
  );
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      {/* Tampilkan nama */}
      <Text style={{ fontSize: 25, fontWeight:'bold'}}>{nama}</Text>
      <Text style={{ marginBottom: 20,fontSize: 15,  color:'gray'}}>{NoHP}</Text>
      <TouchableOpacity style={[styles.button, { flexDirection: 'row' }]} onPress={()=>Navigation.navigate('EditProfileCustomer',{IdProfileCustomer})}>
        <Ionicons name="person-circle-sharp" size={24} color="black" style={{ marginLeft: 10 }} />
        <Text style={styles.text}>Edit Profil</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button, { flexDirection: 'row' }]} onPress={() => Navigation.navigate('Awal')}>
        <Ionicons name="log-out" size={24} color="black" style={{ marginLeft: 10 }} />
        <Text style={styles.text}>Keluar</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  button: {
    height: 50,
    width: '80%',
    backgroundColor: 'gray',
    borderRadius: 10,
    marginBottom: 10,
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  text: {
    color: 'black',
    fontSize: 16,
    marginLeft: 20,
  },
});
