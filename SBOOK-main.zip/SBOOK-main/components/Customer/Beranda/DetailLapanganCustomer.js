import { StyleSheet, Text, View, TouchableOpacity, Alert } from 'react-native';
import React, { useState, useEffect } from 'react';
import { useNavigation, useRoute } from '@react-navigation/native';
import { db, doc, getDoc } from '../../../firebase/firebase';

export default function DetailLapanganCustomer() {
  const navigation = useNavigation();
  const route = useRoute();
  const { lapanganId, IdProfileCustomer, JenisLapangan } = route.params;
  const [lapanganDetail, setLapanganDetail] = useState(null);
console.log(lapanganId)
console.log(JenisLapangan)
  // Mengambil detail lapangan berdasarkan ID dan jenis lapangan
  const getLapanganDetail = async () => {
    try {
        if (!lapanganId || !JenisLapangan) {
            throw new Error('Parameter lapanganId atau JenisLapangan kosong');
          }
      
        const collectionMap = {
            Basket: 'Data Lapangan Basket',
            Badminton: 'Data Lapangan Badminton',
            Futsal: 'Data Lapangan Futsal',
          };
      
        const collectionName = collectionMap[JenisLapangan];
          if (!collectionName) {
            throw new Error('Jenis lapangan tidak valid');
          }
      
        const docRef = doc(db, collectionName, lapanganId);
        const docSnap = await getDoc(docRef);
      
          if (docSnap.exists()) {
            setLapanganDetail(docSnap.data());
            console.log('Detail Lapangan:', docSnap.data());
          } else {
            Alert.alert('Peringatan', 'Data lapangan tidak ditemukan.');
          }
        } catch (error) {
          console.error('Gagal memuat detail lapangan:', error.message);
          Alert.alert('Error', error.message);
        }
      };

  useEffect(() => {
    getLapanganDetail();
  }, [lapanganId, JenisLapangan]);

  if (!lapanganDetail) {
    return <Text>Loading...</Text>;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.lapanganText}>Nama Lapangan: {lapanganDetail.namaLapangan}</Text>
      <Text style={styles.lapanganText}>Jenis Lapangan: {JenisLapangan}</Text>
      <Text style={styles.lapanganText}>Jam Operasional: {lapanganDetail.JamMulai} - {lapanganDetail.JamSelesai}</Text>
      <Text style={styles.lapanganText}>Harga: {lapanganDetail.Harga}</Text>
      <Text style={styles.lapanganText}>Alamat: {lapanganDetail.Alamat}</Text>
      <Text style={styles.lapanganText}>Fasilitas: {lapanganDetail.fasilitas}</Text>

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Penyewaan', { lapanganId, IdProfileCustomer, JenisLapangan })}
      >
        <Text style={styles.buttonText}>Lakukan Penyewaan</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  lapanganText: {
    fontSize: 18,
    marginVertical: 5,
  },
  button: {
    marginTop: 20,
    padding: 10,
    backgroundColor: 'black',
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
});
