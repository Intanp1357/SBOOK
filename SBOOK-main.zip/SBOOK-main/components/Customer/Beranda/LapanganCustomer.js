import { StyleSheet, Text, View, ScrollView, TouchableOpacity, Alert } from 'react-native';
import React, { useState, useEffect } from 'react';
import { useNavigation, useRoute } from '@react-navigation/native';
import { db, collection, getDocs } from '../../../firebase/firebase';

export default function LapanganCustomer() {
  const navigation = useNavigation();
  const route = useRoute();
  const [dataLapangan, setDataLapangan] = useState({
    basket: [],
    badminton: [],
    futsal: [],
  });

  const { IdProfileCustomer } = route.params;

  // Ambil data dari semua koleksi
  const fetchAllLapangan = async () => {
    try {
      const basketCollection = collection(db, "Data Lapangan Basket");
      const badmintonCollection = collection(db, "Data Lapangan Badminton");
      const futsalCollection = collection(db, "Data Lapangan Futsal");

      const [basketSnap, badmintonSnap, futsalSnap] = await Promise.all([
        getDocs(basketCollection),
        getDocs(badmintonCollection),
        getDocs(futsalCollection),
      ]);

      const basketData = basketSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      const badmintonData = badmintonSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      const futsalData = futsalSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      setDataLapangan({
        basket: basketData,
        badminton: badmintonData,
        futsal: futsalData,
      });

      console.log('Data Lapangan:', { basket: basketData, badminton: badmintonData, futsal: futsalData });
    } catch (error) {
      console.log('Gagal memuat data lapangan:', error.message);
      Alert.alert('Error', 'Terjadi kesalahan saat memuat data lapangan.');
    }
  };

  useEffect(() => {
    fetchAllLapangan();
  }, []);

  return (
    <ScrollView style={styles.container}>
      <Text style={{ marginTop: 50, marginLeft: 10, fontSize: 20 }}>Semua Lapangan</Text>

      {dataLapangan.basket.map((lapangan) => (
        <TouchableOpacity
          key={lapangan.id}
          style={styles.lapanganCard}
          onPress={() =>
            navigation.navigate('Detail Lapangan', { lapanganId: lapangan.id, IdProfileCustomer,JenisLapangan:'Basket'})
          }
        >
          <Text style={styles.lapanganText}>Nama Lapangan: {lapangan.namaLapangan}</Text>
          <Text style={styles.lapanganText}>Jam Operasional: {lapangan.JamMulai} - {lapangan.JamSelesai}</Text>
          <Text style={styles.lapanganText}>Harga: {lapangan.Harga}</Text>
        </TouchableOpacity>
      ))}

      
      {dataLapangan.badminton.map((lapangan) => (
        <TouchableOpacity
          key={lapangan.id}
          style={styles.lapanganCard}
          onPress={() =>
            navigation.navigate('Detail Lapangan', { lapanganId: lapangan.id, IdProfileCustomer,JenisLapangan:'Badminton'})
          }
        >
          <Text style={styles.lapanganText}>Nama Lapangan: {lapangan.namaLapangan}</Text>
          <Text style={styles.lapanganText}>Jam Operasional: {lapangan.JamMulai} - {lapangan.JamSelesai}</Text>
          <Text style={styles.lapanganText}>Harga: {lapangan.Harga}</Text>
        </TouchableOpacity>
      ))}

      {/* Lapangan Futsal */}
      {dataLapangan.futsal.map((lapangan) => (
        <TouchableOpacity
          key={lapangan.id}
          style={styles.lapanganCard}
          onPress={() =>
            navigation.navigate('Detail Lapangan', { lapanganId: lapangan.id,IdProfileCustomer,jenisLapangan: 'Futsal'})
          }
        >
          <Text style={styles.lapanganText}>Nama Lapangan: {lapangan.namaLapangan}</Text>
          <Text style={styles.lapanganText}>Jam Operasional: {lapangan.JamMulai} - {lapangan.JamSelesai}</Text>
          <Text style={styles.lapanganText}>Harga: {lapangan.Harga}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  categoryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 5,
  },
  lapanganCard: {
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    marginVertical: 5,
    borderRadius: 5,
  },
  lapanganText: {
    fontSize: 16,
  },
});
