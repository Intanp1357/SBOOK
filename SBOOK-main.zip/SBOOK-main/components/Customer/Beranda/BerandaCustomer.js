import { StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React from 'react'
import { useNavigation,useRoute } from '@react-navigation/native';
import Foundation from '@expo/vector-icons/Foundation';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import Ionicons from '@expo/vector-icons/Ionicons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import BerandaCustomer2 from './BerandaCustomer2';
import LapanganCustomer from './LapanganCustomer';
import RiwayatCustomer from './RiwayatCustomer';
import ProfileCustomer from './ProfileCustomer';

export default function BerandaCustomer() {
  const Tab = createBottomTabNavigator()
  const Route = useRoute()
  return (
      <Tab.Navigator
        screenOptions={{
          tabBarShowLabel: false,
          headerShown: false,
          tabBarStyle:{
              bottom:0,
              right:0,
              left:0,
              elevation:0,
              backgroundColor:'white',
              borderTopWidth:3,
              borderTopColor:"gray"
          }
        }}
      >
        <Tab.Screen
          name="Beranda"
          component={BerandaCustomer2}
          initialParams={{ IdProfileCustomer: Route.params.IdProfileCustomer }}
          options={{
            tabBarIcon: ({ focused }) => {return(
              <View style={{alignItems:'center', justifyContent:'center'}}>
                <MaterialCommunityIcons
                  name="home-variant"
                  size={27}
                  color={focused ? "black" : "gray"}
                />
                <Text style={{ color: focused ? "black" : "gray", fontSize:8 }}>Beranda</Text>
              </View>
            );
            }}}
            
        />
        <Tab.Screen
          name="Lapangan"
          component={LapanganCustomer}
          initialParams={{ IdProfileCustomer: Route.params.IdProfileCustomer }}
          options={{
            tabBarIcon: ({ focused }) => {return(
              <View style={{justifyContent:'center',alignItems:'center'}}>
                              <MaterialCommunityIcons
                  name="soccer-field"
                  size={27}
                  color={focused ? "black" : "gray"}
                />
                <Text style={{ color: focused ? "black" : "gray", fontSize:7}}>Lapangan</Text>
              </View>
            );
          }}}
        />
          <Tab.Screen
          name="Riwayat"
          component={RiwayatCustomer}
          initialParams={{ IdProfileCustomer: Route.params.IdProfileCustomer }}
          options={{
            tabBarIcon: ({ focused }) => {return(
              <View style={{justifyContent:'center',alignItems:'center'}}>
                <MaterialIcons name="calendar-month" size={27} color={focused ? "black" : "gray"} />
                <Text style={{ color: focused ? "black" : "gray", fontSize:8 }}>Riwayat</Text>
              </View>
            );
            }}}
        />
          <Tab.Screen
          initialParams={{ IdProfileCustomer: Route.params.IdProfileCustomer }}
          name="Profile"
          component={ProfileCustomer}
          options={{
            tabBarIcon: ({ focused }) => {return(
              <View style={{justifyContent:'center',alignItems:'center'}}>
                <Ionicons name="person-sharp" size={24} color={focused ? "black":"gray"} />
                <Text style={{ color: focused ? "black" : "gray" , fontSize:8}}>Profile</Text>
              </View>
            );
            }}}
        />
      </Tab.Navigator>
  
    );
  }
  
  const styles = StyleSheet.create({
    iconContainer: {
      alignItems: "center",
      justifyContent: "center",
    },
  });
  
