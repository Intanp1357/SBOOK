import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import React, { useState } from 'react';
import { useNavigation } from '@react-navigation/native';
import { db,collection, addDoc , getDocs, doc, deleteDoc,getAuth, createUserWithEmailAndPassword } from '../../../firebase/firebase';

export default function RegisterAdmin() {
  const navigation = useNavigation();
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [sportType, setSportType] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const auth = getAuth()
  const handleRegister = async() => {
    if (!name || !address || !sportType || !phoneNumber || !username || !password) {
      Alert.alert('Peringatan', 'Semua kolom harus diisi!');
      return;
    }
    if (name.length > 50) {
      Alert.alert('Peringatan', 'Nama Lapangan maksimal 50 karakter!');
      return;
    }
    if (address.length < 20) {
      Alert.alert('Peringatan', 'Alamat minimal 20 karakter!');
      return;
    }
    const validSports = ['basket', 'badminton', 'futsal'];
    if (!validSports.includes(sportType.toLowerCase())) {
      Alert.alert('Peringatan', 'Jenis olahraga harus basket, badminton, atau futsal!');
      return;
    }
    if (!/^\d{10,12}$/.test(phoneNumber)) {
      Alert.alert('Peringatan', 'Nomor handphone harus terdiri dari 10-12 angka!');
      return;
    }
    if (username.length <= 10) {
      Alert.alert('Peringatan', 'Username terlalu pendek');
      return;
    }
    if (!username.includes('@')) {
      Alert.alert('Peringatan', 'Username harus mengandung karakter "@"!');
      return;
    }
    if (password.length > 8) {
      Alert.alert('Peringatan', 'Password maksimal 8 karakter!');
      return;
    }
    try {
        const userCredential = await createUserWithEmailAndPassword(auth, username, password);
        const user = userCredential.user;
        await addProfileAdmin();

        navigation.navigate('Login Admin');
      } catch (error) {
        console.error("Error saat registrasi:", error.message);
        Alert.alert('Error', error.message);
      }
  };
  const addProfileAdmin = async()=>{
    try {
      const docRef = await addDoc(collection(db, "Profile Admin"), {
        NamaGedung : name,
        Alamat : address,
        JenisLapangan : sportType,
        NoHP : phoneNumber,
        Username : username,
        Password : password
      });
      console.log("Document written with ID: ", docRef.id);
      setName('');
      setAddress('');
      setSportType('');
      setPhoneNumber('');
      setUsername('');
      setPassword('');
    } catch (e) {
      console.error("Error adding document: ", e);
    }
  }
  return (
    <>
      <Text style={styles.Teks}>REGISTER</Text>
      <View style={styles.container}>
        <Text style={{fontWeight: 'bold'}}>Nama Lapangan</Text>
        <TextInput
          placeholder="Masukkan Nama"
          style={styles.tombol}
          value={name}
          onChangeText={setName} // Menyimpan input ke state
        />
        <Text style={{fontWeight: 'bold'}}>Alamat</Text>
        <TextInput
          placeholder="Masukkan Alamat"
          style={styles.tombol}
          value={address}
          onChangeText={setAddress}
        />
        <Text style={{fontWeight: 'bold'}}>Jenis Olahraga</Text>
        <TextInput
          placeholder="Masukkan Jenis Olahraga"
          style={styles.tombol}
          value={sportType}
          onChangeText={setSportType}
        />
        <Text style={{fontWeight: 'bold'}}>No HP</Text>
        <TextInput
          placeholder="Masukkan Nomor Handphone"
          style={styles.tombol}
          value={phoneNumber}
          onChangeText={setPhoneNumber}
          keyboardType="numeric" // Keyboard angka
        />
        <Text style={{fontWeight: 'bold'}}>Username</Text>
        <TextInput
          placeholder="Masukkan Username"
          style={styles.tombol}
          value={username}
          onChangeText={setUsername}
        />
        <Text style={{fontWeight: 'bold'}}>Password</Text>
        <TextInput
          placeholder="Masukkan Password"
          style={styles.tombol}
          value={password}
          onChangeText={setPassword}
          secureTextEntry // Mengamankan password
        />
        <TouchableOpacity
          style={{
            marginTop: 30,
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: 'black',
            width: '90%',
            height: 50,
            borderRadius: 20,
          }}
          onPress={handleRegister} // Menggunakan fungsi handleRegister
        >
          <Text style={styles.textmasuk}>Masuk</Text>
        </TouchableOpacity>
        <Text style={{marginLeft: 110}}>Sudah Punya Akun?</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Login Admin')}>
          <Text style={{marginLeft: 150, textDecorationLine: 'underline', color: 'blue'}}>Login</Text>
        </TouchableOpacity>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginLeft: 20,
    marginTop: 40,
  },
  Teks: {
    fontSize: 20,
    color: 'black',
    fontWeight: 'bold',
    alignSelf: 'center',
    marginTop: 70,
  },
  input: {
    borderColor: '#211A2C',
    borderWidth: 3,
    borderRadius: 10,
    width: '80%',
    marginBottom: 20,
  },
  tombol: {
    borderColor: 'grey',
    borderWidth: 3,
    width: '90%',
    borderRadius: 20,
    marginBottom: 15,
  },
  textmasuk: {
    fontSize: 16,
    color: 'white',
  },
});
