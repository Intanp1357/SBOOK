import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function BerandaAdmin2() {
  return (
    <View style={styles.container}>
      <Text style={{marginTop:50, marginLeft:10, fontSize:43}}>SBOOK !</Text>
      <Text style={{marginLeft:10, fontSize:15, color:'gray'}}>Selamat Datang AdminBook, Tambahkan Jadwal Lapangan Kamu dan Dapatkan Banyak Cuan</Text>
      <View style={{
        flex:1,
        flexDirection:'column',
        marginTop:20,

      }}>
      <Text style={{ marginTop:10,alignSelf:'center', fontSize:15, color:'black', fontWeight:'bold'}}>PERSETUJUAN PENYEWAAN</Text>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        
    }
})