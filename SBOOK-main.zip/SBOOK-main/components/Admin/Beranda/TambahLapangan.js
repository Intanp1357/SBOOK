import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, Alert, StyleSheet, TouchableOpacity } from 'react-native';
import { useRoute } from '@react-navigation/native';
import AntDesign from '@expo/vector-icons/AntDesign';
import { db,collection, addDoc , getDoc,getDocs, doc, deleteDoc,getAuth, createUserWithEmailAndPassword } from '../../../firebase/firebase';

export default function TambahLapangan() {
  const [namaGedung,setNamaGedung] = useState('')
  const [NoHP, setNoHP] = useState('')
  const [Alamat, setAlamat] = useState('')
  const [JenisL, setJenisL] = useState('')
  const [namaLapangan, setNamaLapangan] = useState('');
  const [jamMulai, setJamMulai] = useState('');
  const [jamSelesai, setJamSelesai] = useState('');
  const [fasilitas, setFasilitas] = useState('');
  const [harga, setHarga] = useState('');
  const Route = useRoute()
  const {IdProfileAdmin} = Route.params
  console.log(IdProfileAdmin)

  const validateInput = () => {
    if (!namaLapangan || !jamMulai || !jamSelesai || !fasilitas || !harga) {
      Alert.alert('Error', 'Semua kolom harus diisi!');
      return false;
    }

    if (namaLapangan.length <= 10) {
      Alert.alert('Error', 'Nama lapangan harus lebih dari 10 karakter!');
      return false;
    }

    if (!isValidTime(jamMulai) || !isValidTime(jamSelesai)) {
      Alert.alert('Error', 'Format jam tidak valid (contoh: 19:00)!');
      return false;
    }

    if (jamMulai >= jamSelesai) {
      Alert.alert('Error', 'Jam mulai harus lebih kecil dari jam selesai!');
      return false;
    }

    if (isNaN(harga) || parseFloat(harga) <= 0) {
      Alert.alert('Error', 'Harga harus berupa angka positif!');
      return false;
    }

    return true;
  };

  const isValidTime = (time) => {
    const timePattern = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/; 
    return timePattern.test(time);
  };
  
  const getProfileAdmin = async () => {
    const { IdProfileAdmin } = Route.params || {}; 
    if (!IdProfileAdmin) {
      console.log('IdProfileAdmin tidak diteruskan!');
      return;
    }
    console.log(IdProfileAdmin); 
    try {
      const docRef = doc(db, 'Profile Admin', IdProfileAdmin); 
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const userData = docSnap.data(); // Ambil data dokumen
        console.log('Data Profil Admin:', userData);
        if (userData.NamaGedung) {
          setNamaGedung(userData.NamaGedung); // Simpan nama di state
        }
        if (userData.NoHP){
            setNoHP(userData.NoHP)
        }
        if (userData.Alamat){
            setAlamat(userData.Alamat)
        }
        setJenisL(userData.JenisLapangan)
      } else {
        console.log('Data tidak ditemukan untuk ID ini!');
      }
    } catch (error) {
      console.error('Gagal mengambil data:', error.message);
    }
  };

  const checkDuplicateLapangan = async () => {
    try {
      let usersCollection;
      if (JenisL === 'Basket') {
        usersCollection = collection(db, "Data Lapangan Basket");
      } else if (JenisL === 'Badminton') {
        usersCollection = collection(db, "Data Lapangan Badminton");
      } else if (JenisL === 'Futsal') {
        usersCollection = collection(db, "Data Lapangan Futsal");
      } else {
        console.log("Jenis lapangan tidak valid");
        return;
      }
      const querySnapshot = await getDocs(usersCollection);
      let isDuplicate = false;
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        if (
          data.IdGedung === IdProfileAdmin &&
          data.namaLapangan === namaLapangan &&
          data.JamMulai === jamMulai &&
          data.JamSelesai === jamSelesai
        ) {
          isDuplicate = true;
        }
      });
      return isDuplicate;
    } catch (error) {
      console.error("Error checking duplicate: ", error.message);
      return true; 
    }
  };
  const handleTambahLapangan = async () => {
    if (validateInput()) {
      const isDuplicate = await checkDuplicateLapangan();
      if (isDuplicate) {
        Alert.alert("Error", "Data lapangan sudah ada!");
        return;
      }
      await TambahDataLapanganBasket();
      Alert.alert("Sukses", "Data lapangan berhasil ditambahkan!");
    }
  };
  const TambahDataLapanganBasket = async()=>{
    try {
      let usersCollection;
      if (JenisL === 'Basket') {
        usersCollection = collection(db, "Data Lapangan Basket");
      } else if (JenisL === 'Badminton') {
        usersCollection = collection(db, "Data Lapangan Badminton");
      } else if (JenisL === 'Futsal') {
        usersCollection = collection(db, "Data Lapangan Futsal");
      } else {
        console.log("Jenis lapangan tidak valid");
        return;
      }
      const docRef = await addDoc(usersCollection, {
        IdGedung : IdProfileAdmin,
        NamaGedung : namaGedung,
        namaLapangan: namaLapangan,
        JamMulai : jamMulai,
        JamSelesai : jamSelesai,
        Harga : harga,
        fasilitas: fasilitas,
        Alamat : Alamat,
        JenisLapangan : JenisL,
        NoHP : NoHP,
      });
      console.log("Document written with ID: ", docRef.id);
      setNamaLapangan('')
      setFasilitas('')
      setJamMulai('')
      setJamSelesai('')
      setHarga('')
    } catch (e) {
      console.error("Error adding document: ", e);
    }
  }
  useEffect(() => {
    getProfileAdmin();
  }, [Route.params.IdProfileAdmin]);

  return (
    <View style={styles.container}>
      <Text style={{alignSelf:'center',fontWeight:'bold', marginBottom:20}}> TAMBAHKAN DATA LAPANGAN BARU</Text>
      <TextInput
        style={styles.input}
        placeholder="Masukkan Nama Lapangan"
        value={namaLapangan}
        onChangeText={setNamaLapangan}
      />
      <TextInput
        style={styles.input}
        placeholder="Masukkan Jam Mulai (contoh: 19:00)"
        value={jamMulai}
        onChangeText={setJamMulai}
      />
      <TextInput
        style={styles.input}
        placeholder="Masukkan Jam Selesai (contoh: 20:00)"
        value={jamSelesai}
        onChangeText={setJamSelesai}
      />
      <TextInput
        style={styles.input}
        placeholder="Masukkan Fasilitas"
        value={fasilitas}
        onChangeText={setFasilitas}
      />
      <TextInput
        style={styles.input}
        placeholder="Masukkan Harga"
        keyboardType="numeric"
        value={harga}
        onChangeText={setHarga}
      />
      <TouchableOpacity style={{paddingLeft:155}}><AntDesign name="pluscircle" size={30} color="black" onPress={handleTambahLapangan}/></TouchableOpacity>
     
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
    
  },
  input: {
    marginBottom: 15,
    borderWidth: 2,
    borderColor: 'gray',
    width: '100%',
    padding: 10,
    borderRadius: 5,
  },
});
