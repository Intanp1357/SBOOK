import React from "react";
import {TouchableOpacity, View, StyleSheet, Text, Alert} from "react-native";
import { useState, useEffect } from "react";
import { TextInput } from "react-native-gesture-handler";
import { useNavigation, useRoute } from "@react-navigation/native";
import { db, doc,getDoc, getDocs, updateDoc, collection} from '../../../../firebase/firebase';

export default function EditNoHp(){
  const route = useRoute();
  const { IdProfileAdmin } = route.params;
  const [NoHp, setNoHp] = useState("");
  const [newNoHp, setNewNoHp] = useState("");

  const getProfileAdmin = async () => {
    if (!IdProfileAdmin) {
      console.log("IdProfileAdmin tidak diteruskan!");
      return;
    }
    try {
      const docRef = doc(db, "Profile Admin", IdProfileAdmin);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const userData = docSnap.data();
        setNoHp(userData.NoHP);
      } else {
        console.log("Dokumen tidak ditemukan!");
      }
    } catch (error) {
      console.error("Gagal mengambil data:", error.message);
    }
  };

  const updateNoHP = async () => {
    if (!newNoHp.trim()) {
      Alert.alert("Peringatan", "Nama gedung tidak boleh kosong!");
      return;
    }
    try {
      const docRefProfileAdmin = doc(db, "Profile Admin", IdProfileAdmin);
      await updateDoc(docRefProfileAdmin, { NoHP: newNoHp });

      const lapanganCollections = [
        collection(db, "Data Lapangan Basket"),
        collection(db, "Data Lapangan Badminton"),
        collection(db, "Data Lapangan Futsal"),
      ];
  
      const allLapanganSnapshots = await Promise.all(lapanganCollections.map(getDocs));
  
      const updates = allLapanganSnapshots.flatMap((snapshot) =>
        snapshot.docs
          .filter((lapanganDoc) => lapanganDoc.data().IdGedung === IdProfileAdmin)
          .map((lapanganDoc) => {
            const lapanganRef = doc(db, lapanganDoc.ref.parent.path, lapanganDoc.id);
            return updateDoc(lapanganRef, {NoHP: newNoHp });
          })
      );
      await Promise.all(updates);
      Alert.alert("Sukses", "No HP berhasil diperbarui di semua lapangan!");
      setNewNoHp(""); // Reset input field
    } catch (error) {
      console.error("Gagal memperbarui data:", error.message);
      Alert.alert("Error", "Gagal memperbarui nama gedung dan lapangan!");
    }
  };

  useEffect(() => {
    getProfileAdmin();
  }, [IdProfileAdmin]);

  return (
    <View style={styles.container}>
      <Text style={{ fontWeight: "bold", marginBottom: 10 }}>No HP Saat Ini</Text>
      <Text style={{ alignItems: "center", borderWidth: 1, marginBottom: 10, height: 25 }}> {NoHp}</Text>
      <TextInput
        placeholder="Masukkan NoHP Baru"
        value={newNoHp}
        onChangeText={setNewNoHp}
        style={styles.textBox}
      />
      <TouchableOpacity style={styles.button} onPress={updateNoHP}>
        <Text style={styles.buttonText}>Update NoHP</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 175,
    padding: 20,
  },
  textBox: {
    borderWidth: 1,
    borderColor: "black",
    padding: 10,
    marginBottom: 20,
  },
  button: {
    backgroundColor: "#4CAF50",
    padding: 10,
    alignItems: "center",
    borderRadius: 5,
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
  },
});
