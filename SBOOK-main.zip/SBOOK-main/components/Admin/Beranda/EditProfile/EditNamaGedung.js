import React, { useState, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from "react-native";
import { useRoute } from "@react-navigation/native";
import { db, doc, getDoc, updateDoc, collection, getDocs } from "../../../../firebase/firebase";

export default function EditNamaGedung() {
  const route = useRoute();
  const { IdProfileAdmin } = route.params;
  const [NamaGedung, setNamaGedung] = useState("");
  const [newNamaGedung, setNewNamaGedung] = useState("");
  const [jenisLapangan, setJenisLapangan] = useState("");

  const getProfileAdmin = async () => {
    if (!IdProfileAdmin) {
      console.log("IdProfileAdmin tidak diteruskan!");
      return;
    }
    try {
      const docRef = doc(db, "Profile Admin", IdProfileAdmin);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const userData = docSnap.data();
        setNamaGedung(userData.NamaGedung);
        setJenisLapangan(userData.JenisLapangan); 
      } else {
        console.log("Dokumen tidak ditemukan!");
      }
    } catch (error) {
      console.error("Gagal mengambil data:", error.message);
    }
  };

  const updateNamaGedung = async () => {
    if (!newNamaGedung.trim()) {
      Alert.alert("Peringatan", "Nama gedung tidak boleh kosong!");
      return;
    }
    try {
      const docRefProfileAdmin = doc(db, "Profile Admin", IdProfileAdmin);
      await updateDoc(docRefProfileAdmin, { NamaGedung: newNamaGedung });

      const lapanganCollections = [
        collection(db, "Data Lapangan Basket"),
        collection(db, "Data Lapangan Badminton"),
        collection(db, "Data Lapangan Futsal"),
      ];
  
      // Mendapatkan semua dokumen dari semua koleksi
      const allLapanganSnapshots = await Promise.all(lapanganCollections.map(getDocs));
  
      // Menggabungkan semua dokumen dan melakukan filter berdasarkan IdGedung
      const updates = allLapanganSnapshots.flatMap((snapshot) =>
        snapshot.docs
          .filter((lapanganDoc) => lapanganDoc.data().IdGedung === IdProfileAdmin)
          .map((lapanganDoc) => {
            const lapanganRef = doc(db, lapanganDoc.ref.parent.path, lapanganDoc.id);
            return updateDoc(lapanganRef, { NamaGedung: newNamaGedung });
          })
      );
  
      await Promise.all(updates);

      Alert.alert("Sukses", "Nama gedung berhasil diperbarui di semua lapangan!");
      setNewNamaGedung(""); // Reset input field
    } catch (error) {
      console.error("Gagal memperbarui data:", error.message);
      Alert.alert("Error", "Gagal memperbarui nama gedung dan lapangan!");
    }
  };

  useEffect(() => {
    getProfileAdmin();
  }, [IdProfileAdmin]);

  return (
    <View style={styles.container}>
      <Text style={{ fontWeight: "bold", marginBottom: 10 }}>Nama Gedung Saat Ini</Text>
      <Text style={{ alignItems: "center", borderWidth: 1, marginBottom: 10, height: 25 }}> {NamaGedung}</Text>
      <TextInput
        placeholder="Masukkan Nama Gedung Baru"
        value={newNamaGedung}
        onChangeText={setNewNamaGedung}
        style={styles.textBox}
      />
      <TouchableOpacity style={styles.button} onPress={updateNamaGedung}>
        <Text style={styles.buttonText}>Update Nama Gedung</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 175,
    padding: 20,
  },
  textBox: {
    borderWidth: 1,
    borderColor: "black",
    padding: 10,
    marginBottom: 20,
  },
  button: {
    backgroundColor: "#4CAF50",
    padding: 10,
    alignItems: "center",
    borderRadius: 5,
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
  },
});
