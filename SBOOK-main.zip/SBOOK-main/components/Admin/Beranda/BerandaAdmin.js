import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import Ionicons from '@expo/vector-icons/Ionicons';
import Lapangan from './Lapangan';
import BerandaAdmin2 from './BerandaAdmin2';
import RiwayatAdmin from './Riwayat';
import ProfileAdmin from './Profile';
import { useRoute } from '@react-navigation/native';

export default function BerandaAdmin() {
  const Tab = createBottomTabNavigator();
  const Route = useRoute()
  

  return (

    <Tab.Navigator
      screenOptions={{
        tabBarShowLabel: false,
        headerShown: false,
        tabBarStyle:{
            bottom:0,
            right:0,
            left:0,
            elevation:0,
            backgroundColor:'white',
            borderTopWidth:3,
            borderTopColor:"gray"
        }
      }}
    >
      <Tab.Screen
        name="Beranda"
        component={BerandaAdmin2}
        initialParams={{ IdProfileAdmin: Route.params.IdProfileAdmin }}
        options={{
          tabBarIcon: ({ focused }) => {return(
            <View style={{alignItems:'center', justifyContent:'center'}}>
              <MaterialCommunityIcons
                name="home-variant"
                size={27}
                color={focused ? "black" : "gray"}
              />
              <Text style={{ color: focused ? "black" : "gray", fontSize:8 }}>Beranda</Text>
            </View>
          );
          }}}
          
      />
      <Tab.Screen
        name="Lapangan"
        component={Lapangan}
        initialParams={{ IdProfileAdmin: Route.params.IdProfileAdmin }}
        options={{
          tabBarIcon: ({ focused }) => {return(
            <View style={{justifyContent:'center',alignItems:'center'}}>
                            <MaterialCommunityIcons
                name="soccer-field"
                size={27}
                color={focused ? "black" : "gray"}
              />
              <Text style={{ color: focused ? "black" : "gray", fontSize:7}}>Lapangan</Text>
            </View>
          );
        }}}
      />
        <Tab.Screen
        name="Riwayat"
        component={RiwayatAdmin}
        initialParams={{ IdProfileAdmin: Route.params.IdProfileAdmin }}
        options={{
          tabBarIcon: ({ focused }) => {return(
            <View style={{justifyContent:'center',alignItems:'center'}}>
              <MaterialIcons name="calendar-month" size={27} color={focused ? "black" : "gray"} />
              <Text style={{ color: focused ? "black" : "gray", fontSize:8 }}>Riwayat</Text>
            </View>
          );
          }}}
      />
        <Tab.Screen
        initialParams={{ IdProfileAdmin: Route.params.IdProfileAdmin }}
        name="Profile"
        component={ProfileAdmin}
        options={{
          tabBarIcon: ({ focused }) => {return(
            <View style={{justifyContent:'center',alignItems:'center'}}>
              <Ionicons name="person-sharp" size={24} color={focused ? "black":"gray"} />
              <Text style={{ color: focused ? "black" : "gray" , fontSize:8}}>Profile</Text>
            </View>
          );
          }}}
      />
    </Tab.Navigator>

  );
}

const styles = StyleSheet.create({
  iconContainer: {
    alignItems: "center",
    justifyContent: "center",
  },
});
