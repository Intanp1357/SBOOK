import { StyleSheet, Text, View, ScrollView, TouchableOpacity, Alert } from 'react-native';
import React, { useState, useEffect } from 'react';
import { useNavigation, useRoute, useFocusEffect } from '@react-navigation/native';
import AntDesign from '@expo/vector-icons/AntDesign';
import { db, collection, getDocs, query, where,doc, getDoc } from '../../../firebase/firebase';

export default function Lapangan() {
  const navigation = useNavigation();
  let usersCollection
  let JenisDataLapangan = ""
  const route = useRoute();
  const [JenisL,setJenisL] = useState('')
  const { IdProfileAdmin } = route.params;
  const [dataLapangan, setDataLapangan] = useState([]); // Perbaikan State
  const getProfileAdmin = async () => {
    const { IdProfileAdmin } = route.params || {}; // Destructuring dengan aman
    if (!IdProfileAdmin) {
      console.log('IdProfileAdmin tidak diteruskan!');
      return;
    }
    console.log(IdProfileAdmin);  
    try {
      const docRef = doc(db, 'Profile Admin', IdProfileAdmin); 
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const userData = docSnap.data(); // Ambil data dokumen
        setJenisL(userData.JenisLapangan)
        console.log('Data Profil Admin:', userData)
        console.log(JenisL)
        console.log(JenisL)
      } else {
        console.log('Data tidak ditemukan untuk ID ini!');
      }
    } catch (error) {
      console.error('Gagal mengambil data:', error.message);
    }
  };
  

  const datalapangan = async () => {
    try {
      let usersCollection;
      if (JenisL === 'Basket') {
        usersCollection = collection(db, "Data Lapangan Basket");
      } else if (JenisL === 'Badminton') {
        usersCollection = collection(db, "Data Lapangan Badminton");
      } else if (JenisL === 'Futsal') {
        usersCollection = collection(db, "Data Lapangan Futsal");
      } else {
        console.log("Jenis lapangan tidak valid");
        return;
      }
      const q = query(usersCollection, where('IdGedung', '==', IdProfileAdmin));
      const querySnapshot = await getDocs(q);

      if (querySnapshot.empty) {
        console.log("datakosong")
      }

      // Kumpulkan semua data lapangan
      const fetchedData = [];
      querySnapshot.forEach((doc) => {
        fetchedData.push({ id: doc.id, ...doc.data() });
      });

      setDataLapangan(fetchedData); // Simpan data ke state
      console.log('Data Lapangan:', fetchedData);
    } catch (error) {
      console.log('Gagal memuat data lapangan:', error.message);
      Alert.alert('Error', 'Terjadi kesalahan saat memuat data lapangan.');
    }
  };
  useEffect(() => {
    getProfileAdmin();
  }, [route.params.IdProfileAdmin]);
  useFocusEffect(
    React.useCallback(() => {
      datalapangan();
    }, [IdProfileAdmin])
  );

  return (
    <ScrollView style={styles.container}>
      <Text style={{ marginTop: 50, marginLeft: 10, fontSize: 20 }}>
        Lapangan yang Dikelola
      </Text>

      {/* Tampilkan data lapangan */}
      {dataLapangan.map((lapangan, index) => (
        <View key={lapangan.id} style={styles.lapanganCard}>
          <Text style={styles.lapanganText}>Nama Lapangan: {lapangan.namaLapangan}</Text>
          <Text style={styles.lapanganText}>Jam Operasional: {lapangan.JamMulai} - {lapangan.JamSelesai}</Text>
          <Text style={styles.lapanganText}>Harga: {lapangan.Harga}</Text>
        </View>
      ))}
      <View style={styles.iconContainer}>
        <TouchableOpacity
          style={styles.iconButton}
          onPress={() =>
            navigation.navigate('Menambah Lapangan', { IdProfileAdmin })
          }
        >
          <AntDesign name="pluscircle" size={30} color="black" />
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  iconContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  iconButton: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  lapanganCard: {
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    marginVertical: 5,
    borderRadius: 5,
  },
  lapanganText: {
    fontSize: 16,
  },
});
