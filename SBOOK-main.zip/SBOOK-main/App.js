import Login from './components/Customer/Login';
import {createStackNavigator} from '@react-navigation/stack'
import { NavigationContainer } from '@react-navigation/native';
import HalamanAwalCustomer from './components/BerandaUmum';
import Berandaawal from './components/BerandaUmum/berandaawal';
import pilihrole from './components/BerandaUmum/pilihadmin';
import RegisterCustomer from './components/Customer/register';
import BerandaCustomer from './components/Customer/Beranda/BerandaCustomer';
import HalamanAwalAdmin from './components/Admin/Beranda/HalamanAwalAdmin';
import RegisterAdmin from './components/Admin/Login/Register';
import LoginAdmin from './components/Admin/Login/Login';
import BerandaAdmin from './components/Admin/Beranda/BerandaAdmin';
import TambahLapangan from './components/Admin/Beranda/TambahLapangan';
import EditProfile from './components/Admin/Beranda/EditProfile';
import EditNamaGedung from './components/Admin/Beranda/EditProfile/EditNamaGedung';
import EditAlamat from './components/Admin/Beranda/EditProfile/EditAlamat';
import EditNoHp from './components/Admin/Beranda/EditProfile/EditNoHp';
import EditUsername from './components/Admin/Beranda/EditProfile/EditJsername';
import EditProfileCustomer from './components/Customer/Beranda/EditProfileCustomer';
import EditNamaCustomer from './components/Customer/Beranda/EditProfile/EditNama';
import EditNoHpCustomer from './components/Customer/Beranda/EditProfile/EditNoHp';
import EditAlamatCustomer from './components/Customer/Beranda/EditProfile/EditAlamat';
import EditUsernameCustomer from './components/Customer/Beranda/EditProfile/EditUsername';
import DetailLapanganCustomer from './components/Customer/Beranda/DetailLapanganCustomer';
import Penyewaan from './components/Customer/Beranda/Penyewaan';


export default function App() {
  const Stack = createStackNavigator();
  return (
    <NavigationContainer>
      <Stack.Navigator>
      <Stack.Screen name="Awal" component={Berandaawal} options={{headerShown:false}}/>
      <Stack.Screen name="Halaman Awal Customer" component={HalamanAwalCustomer} options={{headerShown:false}}/>
      <Stack.Screen name="RegisterCustomer" component={RegisterCustomer} options={{headerShown:false}}/>
      <Stack.Screen name="Login" component={Login} options={{headerShown:false}}/>
      <Stack.Screen name="Pilih" component={pilihrole} options={{headerShown:false}}/>
      <Stack.Screen name="BerandaCustomer" component={BerandaCustomer} options={{headerShown:false}}/>
      <Stack.Screen name="Halaman Awal Admin" component={HalamanAwalAdmin} options={{headerShown:false}}/>
      <Stack.Screen name="RegisterAdmin" component={RegisterAdmin} options={{headerShown:false}} />
      <Stack.Screen name="Login Admin" component={LoginAdmin} options={{headerShown:false}}/>
      <Stack.Screen name="Beranda Admin" component={BerandaAdmin} options={{headerShown:false}}/>
      <Stack.Screen name="Menambah Lapangan" component={TambahLapangan} options={{headerShown:true}}/>
      <Stack.Screen name="EditProfileAdmin" component={EditProfile} options={{headerShown:true}}/>
      <Stack.Screen name="EditNamaGedungAdmin" component={EditNamaGedung} options={{headerShown:true}}/>
      <Stack.Screen name="EditAlamatAdmin" component={EditAlamat} options={{headerShown:true}}/>
      <Stack.Screen name="EditNoHpAdmin" component={EditNoHp} options={{headerShown:true}}/>
      <Stack.Screen name="EditUsernameAdmin" component={EditUsername} options={{headerShown:true}}/>
      <Stack.Screen name="EditProfileCustomer" component={EditProfileCustomer} options={{headerShown:true}}/>
      <Stack.Screen name="EditNamaCustomer" component={EditNamaCustomer} options={{headerShown:true}}/>
      <Stack.Screen name="EditNoHpCustomer" component={EditNoHpCustomer} options={{headerShown:true}}/>
      <Stack.Screen name="EditAlamatCustomer" component={EditAlamatCustomer} options={{headerShown:true}}/>
      <Stack.Screen name="EditUsernameCustomer" component={EditUsernameCustomer} options={{headerShown:true}}/>
      <Stack.Screen name="Detail Lapangan" component={DetailLapanganCustomer} options={{headerShown:true}}/>
      <Stack.Screen name="Penyewaan" component={Penyewaan} options={{headerShown:true}}/>
      </Stack.Navigator>
    </NavigationContainer>
    
  );
}


